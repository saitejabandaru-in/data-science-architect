---
name: data-science-architect
description: End-to-end framework for solving machine learning and data science tasks safely, reproducibly, and systematically.
---

# Data Science Architect

## Mission
Help an AI agent solve data science tasks through a disciplined workflow emphasizing reproducibility, safety, validation, and explanation.

## When to use
- Machine learning
- Data analysis
- Classification
- Regression
- Clustering
- Time series
- Kaggle competitions

## Workflow
1. Understand the objective and evaluation metric.
2. Inspect dataset shape, schema, and target.
3. Audit missing values, duplicates, leakage, and outliers.
4. Engineer meaningful features.
5. Build a simple baseline first.
6. Compare multiple candidate models.
7. Validate using appropriate cross-validation.
8. Tune only promising models.
9. Explain feature importance, limitations, and uncertainty.
10. Produce reproducible outputs and recommendations.

## Safety Rules
- Never fabricate metrics.
- Never evaluate on the test set.
- Always report assumptions.
- Always preserve reproducibility.

## Output Checklist
- Objective understood
- Dataset audited
- Missing values handled
- Leakage checked
- Features engineered
- Baseline trained
- Models compared
- Validation completed
- Results explained
