def checklist():
    return [
        'Inspect data',
        'Clean data',
        'Engineer features',
        'Train baseline',
        'Validate',
        'Interpret'
    ]

if __name__=='__main__':
    print('\n'.join(checklist()))
