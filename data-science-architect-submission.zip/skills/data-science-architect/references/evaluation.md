# Evaluation Checklist
- Match metric to task
- Stratified CV where appropriate
- Report mean and variance
- Analyze errors
- Avoid leakage
