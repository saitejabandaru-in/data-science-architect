# Feature Engineering Checklist
- Missing indicators
- Group statistics
- Ratios
- Interaction terms
- Date features
- Frequency encoding
- Domain features
