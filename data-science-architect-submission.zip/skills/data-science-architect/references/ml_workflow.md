# ML Workflow
1. Define objective
2. Explore data
3. Clean data
4. Engineer features
5. Train baseline
6. Cross-validation
7. Tune
8. Evaluate
9. Document
